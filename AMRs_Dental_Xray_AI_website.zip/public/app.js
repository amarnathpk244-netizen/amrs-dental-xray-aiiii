const fileInput = document.getElementById("fileInput");
const uploadBtn = document.getElementById("uploadBtn");
const cameraBtn = document.getElementById("cameraBtn");
const analyzeBtn = document.getElementById("analyzeBtn");
const removeBtn = document.getElementById("removeBtn");
const againBtn = document.getElementById("againBtn");
const previewWrap = document.getElementById("previewWrap");
const preview = document.getElementById("preview");
const status = document.getElementById("status");
const report = document.getElementById("report");

let selectedFile = null;

uploadBtn.onclick = () => fileInput.click();
cameraBtn.onclick = () => fileInput.click();

fileInput.onchange = () => {
  const file = fileInput.files?.[0];
  if (!file) return;
  if (!["image/jpeg","image/png","image/jpg"].includes(file.type)) {
    status.textContent = "Please choose a JPG, JPEG, or PNG image.";
    return;
  }
  selectedFile = file;
  preview.src = URL.createObjectURL(file);
  previewWrap.classList.remove("hidden");
  analyzeBtn.disabled = false;
  report.classList.add("hidden");
  status.textContent = "X-ray ready for analysis.";
};

removeBtn.onclick = clearImage;
againBtn.onclick = () => { clearImage(); window.scrollTo({top:0,behavior:"smooth"}); };

function clearImage(){
  selectedFile = null;
  fileInput.value = "";
  preview.src = "";
  previewWrap.classList.add("hidden");
  analyzeBtn.disabled = true;
  report.classList.add("hidden");
  status.textContent = "";
}

analyzeBtn.onclick = async () => {
  if (!selectedFile) return;
  analyzeBtn.disabled = true;
  status.textContent = "Analyzing the uploaded X-ray with Gemini…";
  report.classList.add("hidden");

  const form = new FormData();
  form.append("xray", selectedFile);

  try {
    const response = await fetch("/api/analyze", { method:"POST", body:form });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Analysis failed.");
    renderReport(data);
    status.textContent = "Analysis complete.";
    report.classList.remove("hidden");
    report.scrollIntoView({behavior:"smooth"});
  } catch (e) {
    status.textContent = e.message;
  } finally {
    analyzeBtn.disabled = false;
  }
};

function esc(v){
  return String(v ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
function finding(title, obj, lines){
  return `<div class="finding"><h3>${esc(title)}</h3><span class="status-badge">${esc(obj.status)}</span>${lines.map(x=>`<p><span class="label">${esc(x[0])}:</span> ${esc(obj[x[1]])}</p>`).join("")}</div>`;
}
function renderReport(d){
  document.getElementById("confidence").textContent = d.overall_confidence;
  document.getElementById("quality").innerHTML = `<b>Image quality:</b> ${d.image_quality.adequate ? "Adequate for provisional assessment" : "Insufficient for reliable assessment"}<br>${esc(d.image_quality.comment)}`;
  document.getElementById("findings").innerHTML =
    finding("A. Caries", d.findings.caries, [["Observations","observations"],["Tooth / region","teeth_or_region"],["Severity / depth","severity_or_depth"]]) +
    finding("B. Alveolar bone loss", d.findings.alveolar_bone_loss, [["Pattern","pattern"],["Severity","severity"],["Tooth / region","teeth_or_region"],["Observations","observations"]]) +
    finding("C. Periapical lesion", d.findings.periapical_lesion, [["Appearance","appearance"],["Tooth / region","tooth_or_region"],["Observations","observations"]]) +
    finding("D. Impacted tooth", d.findings.impacted_tooth, [["Dentition","dentition"],["FDI / region","fdi_or_region"],["Jaw / side","jaw_side"],["Orientation","orientation"],["Observations","observations"]]) +
    finding("E. Missing tooth", d.findings.missing_tooth, [["FDI / region","fdi_or_region"],["Observations","observations"]]);
  document.getElementById("summary").textContent = d.summary;
  document.getElementById("nextStep").textContent = d.next_clinical_step;
}
