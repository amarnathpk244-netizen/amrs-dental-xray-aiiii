# AMRs Dental X-ray AI

A mobile-first research prototype website:
Upload dental X-ray → send the actual image to Gemini → receive structured AI-assisted provisional radiographic assessment.

## Important
This is NOT a clinically validated diagnostic system. Do not use it as a substitute for a dentist. De-identify patient images and follow your institution's ethics/privacy/consent requirements.

## Run locally

1. Install Node.js 20+.
2. Open a terminal in this folder.
3. Run:
   npm install
4. Set your Gemini API key as an environment variable.
5. Run:
   npm start
6. Open http://localhost:3000

Never put the Gemini API key in `public/app.js` or any browser code.

## Deploy
Deploy this Node.js project to a host that supports a Node/Express server. Add `GEMINI_API_KEY` as a server-side environment variable in the host dashboard. Do not commit `.env`.

The website already uses the uploaded image in the real Gemini API request; there are no hardcoded sample findings.

## Research next steps
For a PhD-grade study, later add expert reference labels, dataset/version tracking, train/validation/test separation if a custom model is developed, and prospective/external validation. Compare AI outputs against expert assessments before making performance claims.
