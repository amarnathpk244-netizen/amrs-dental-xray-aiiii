import express from "express";
import multer from "multer";
import { GoogleGenAI } from "@google/genai";

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }
});

app.use(express.static("public"));

const PORT = process.env.PORT || 3000;
const MODEL = process.env.GEMINI_MODEL || "gemini-3.7-flash";

const schema = {
  type: "object",
  properties: {
    image_quality: {
      type: "object",
      properties: {
        adequate: { type: "boolean" },
        comment: { type: "string" }
      },
      required: ["adequate", "comment"]
    },
    overall_confidence: {
      type: "string",
      enum: ["Higher", "Moderate", "Low", "Uncertain"]
    },
    findings: {
      type: "object",
      properties: {
        caries: {
          type: "object",
          properties: {
            status: { type: "string", enum: ["Identified", "Not identified", "Uncertain"] },
            observations: { type: "string" },
            teeth_or_region: { type: "string" },
            severity_or_depth: { type: "string" }
          },
          required: ["status", "observations", "teeth_or_region", "severity_or_depth"]
        },
        alveolar_bone_loss: {
          type: "object",
          properties: {
            status: { type: "string", enum: ["Not identified", "Possible", "Identified", "Uncertain"] },
            pattern: { type: "string" },
            severity: { type: "string" },
            teeth_or_region: { type: "string" },
            observations: { type: "string" }
          },
          required: ["status", "pattern", "severity", "teeth_or_region", "observations"]
        },
        periapical_lesion: {
          type: "object",
          properties: {
            status: { type: "string", enum: ["Identified", "Not identified", "Uncertain"] },
            appearance: { type: "string" },
            tooth_or_region: { type: "string" },
            observations: { type: "string" }
          },
          required: ["status", "appearance", "tooth_or_region", "observations"]
        },
        impacted_tooth: {
          type: "object",
          properties: {
            status: { type: "string", enum: ["Identified", "Not identified", "Uncertain"] },
            dentition: { type: "string" },
            fdi_or_region: { type: "string" },
            jaw_side: { type: "string" },
            orientation: { type: "string" },
            observations: { type: "string" }
          },
          required: ["status", "dentition", "fdi_or_region", "jaw_side", "orientation", "observations"]
        },
        missing_tooth: {
          type: "object",
          properties: {
            status: { type: "string", enum: ["Identified", "Not identified", "Uncertain"] },
            fdi_or_region: { type: "string" },
            observations: { type: "string" }
          },
          required: ["status", "fdi_or_region", "observations"]
        }
      },
      required: ["caries", "alveolar_bone_loss", "periapical_lesion", "impacted_tooth", "missing_tooth"]
    },
    summary: { type: "string" },
    next_clinical_step: { type: "string" }
  },
  required: ["image_quality", "overall_confidence", "findings", "summary", "next_clinical_step"]
};

const instruction = `
You are an experimental dental radiograph assessment assistant.

Analyze ONLY the uploaded dental radiograph. Do not invent findings, tooth numbers, anatomy, or clinical history.

This is an AI-assisted PROVISIONAL RADIOGRAPHIC ASSESSMENT, not a definitive diagnosis.

First assess image quality: clarity, exposure, positioning, field of view and whether it is actually suitable for dental radiographic assessment. If inadequate, say so clearly and keep findings uncertain.

Assess these categories:
1. Caries: Identified / Not identified / Uncertain. Describe visible enamel/dentinal radiolucency only when supported. Do not make a definitive pulpal diagnosis from a radiograph. Use FDI tooth numbering only when genuinely visible; otherwise use a region.
2. Alveolar bone loss: Not identified / Possible / Identified / Uncertain. Describe horizontal, vertical/angular, mixed or cannot reliably assess; mild/moderate/severe/cannot reliably assess. Do not diagnose periodontitis from radiograph alone.
3. Periapical lesion: Identified / Not identified / Uncertain. Describe radiolucent/radiopaque/mixed/other appearance and tooth/region. Do not label a lesion as cyst, granuloma or other histopathological diagnosis from the radiograph alone.
4. Impacted tooth: Identified / Not identified / Uncertain. Describe primary/permanent if supported, FDI if genuinely visible, jaw/side and orientation.
5. Missing tooth: Identified / Not identified / Uncertain. Do not assume congenital absence from an incomplete field of view.

Confidence must be qualitative: Higher, Moderate, Low, or Uncertain. Never provide a made-up percentage.

If no definite abnormality is visible, use wording equivalent to:
"No definite radiographic abnormality was identified by this experimental AI assessment. This does not exclude disease."

The report must distinguish observation from diagnosis and recommend clinical correlation.

Return ONLY valid JSON matching the supplied schema.
`;

app.post("/api/analyze", upload.single("xray"), async (req, res) => {
  try {
    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: "GEMINI_API_KEY is not configured on the server." });
    }
    if (!req.file) {
      return res.status(400).json({ error: "Please upload a dental X-ray image." });
    }

    const allowed = ["image/jpeg", "image/png", "image/jpg"];
    if (!allowed.includes(req.file.mimetype)) {
      return res.status(400).json({ error: "Please upload a JPG, JPEG, or PNG image." });
    }

    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const base64 = req.file.buffer.toString("base64");

    const response = await ai.models.generateContent({
      model: MODEL,
      contents: [
        { text: instruction },
        { inlineData: { mimeType: req.file.mimetype, data: base64 } }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: schema
      }
    });

    const text = response.text;
    const result = JSON.parse(text);
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({
      error: "Gemini analysis failed. Please check the server/API key and try again."
    });
  }
});

app.get("*", (req, res) => {
  res.sendFile("index.html", { root: "public" });
});

app.listen(PORT, () => console.log(`AMRs Dental X-ray AI running on port ${PORT}`));
